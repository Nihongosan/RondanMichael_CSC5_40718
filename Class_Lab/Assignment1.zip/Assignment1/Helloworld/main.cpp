/* 
 File:   main.cpp
 Author: Michael Rondan
 Created on January 6, 2015, 6:05 PM
 Purpose: Our first program
 */

//system libraries
#include <iostream>
using namespace std;

//User Libraries
  
//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Output Hello World
    cout<<"Hello World"<<endl;
    //Exit stage right!
    return 0;
}

