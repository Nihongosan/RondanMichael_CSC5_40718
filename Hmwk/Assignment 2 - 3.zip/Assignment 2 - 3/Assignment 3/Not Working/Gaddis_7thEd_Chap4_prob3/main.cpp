/* 
 * File: Gaddis_7thEd_Chap4_prob3
 * Author: Michael Rondan
 * Purpose: Magic Dates
 * Created on January 19, 2015, 3:33 PM
 */
//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
//Function Prototypes
//Execution Begins Here!
int main(int argc, char** argv) {
//Execution Begins Here!
    int Mnth, Day, Year, Magic;
    cout<<"input Month two digit only";
    cin>>Mnth;
    cout<<"input Day two digit only";
    cin>>Day;
    cout<<"input Year two digit only";
    cin>>Year;
    if(Mnth*Day)=Year
    Magic=1;
    else(Mnth*Day)=Year
    Magic=0;
    return 0;
}
