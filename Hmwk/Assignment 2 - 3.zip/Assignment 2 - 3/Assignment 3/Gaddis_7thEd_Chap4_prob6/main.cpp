/* File: Gaddis_7thEd_Chap4_prob6
 * Author: Michael Rondan
 * purpose: Mass and Weight
 * Created on January 19, 2015, 4:41 PM
 */
//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
//Function Prototypes
//Execution Begins Here!
int main(int argc, char** argv)
{//Execution Begins Here!
    int  weight, mass;
    10<mass<1000;
    cout<<"enter amount of mass in kilograms ";
    cin>>mass ;   
    weight = mass * 9.8;
    cout<<weight<<endl;    
    return 0;
}

